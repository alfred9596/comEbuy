<?php $__env->startSection('pages'); ?>
<?php
    $datass=DB::select('select * from member');
?>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            <?php echo $__env->make('signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            <?php echo $__env->make('cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        </div>
    <div class="col-lg-10">
        <div class="container">
            <h1>Aksesoris</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Username</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->usernama); ?></div></td>
                        <td><a href=<?php echo e(url('delete_member')); ?>/<?php echo e($data->member_id); ?>>Delete</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>