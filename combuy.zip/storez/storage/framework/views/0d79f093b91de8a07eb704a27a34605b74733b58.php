<?php $__env->startSection('pages'); ?>
<?php
    $datass=DB::select('select * from aksesoris');
?>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            <?php echo $__env->make('signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            <?php echo $__env->make('cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        </div>
    <div class="col-lg-10">
        <div class="container">
            <h1>Aksesoris</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Item Type</th>
                    <th>Brand</th>
                    <th>Inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->nama); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->deskripsi); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->harga); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->type); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->brand); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->inserter); ?></div></td>
                        <!--<td><a href="">Add to cart</a></a> -->
                        <?php if(session()->has('members')): ?>
                        <td><a href=<?php echo e(url('update_aksesoris')); ?>/<?php echo e($data->acc_id); ?>>Edit</a></td>
                        <?php endif; ?>
                        <?php if(session()->has('admin')): ?>
                        <td><a href=<?php echo e(url('delete_aksesoris')); ?>/<?php echo e($data->acc_id); ?>>Delete</a></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
            <?php if(session()->has('members')): ?>
                <a href="insert_aksesoris">Insert</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>