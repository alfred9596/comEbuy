<?php $__env->startSection('pages'); ?>
<?php
    $datass=DB::select('select * from notebook');
?>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            <?php echo $__env->make('signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            <?php echo $__env->make('cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        </div>
    <div class="col-lg-10">
        <div class="container">
            <h1>Laptop</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Model</th>
                    <th>Processor</th>
                    <th>OS</th>
                    <th>Storage</th>
                    <th>RAM</th>
                    <th>Graphic</th>
                    <th>Connection</th>
                    <th>Camera</th>
                    <th>Display</th>
                    <th>Colour</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->nama); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->prosesor); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->os); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->storage); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->ram); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->graphic); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->koneksi); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->kamera); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->display); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->warna); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->brand); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->harga); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->inserter); ?></div></td>
                        <td><a href="">Add to cart</a></a> 
                        <?php if(session()->has('members')): ?>
                        <td><a href=<?php echo e(url('update_laptop')); ?>/<?php echo e($data->laptop_id); ?>>Edit</a></td>
                        <?php endif; ?>
                        <?php if(session()->has('members')): ?>
                        <td><a href=<?php echo e(url('delete_laptop')); ?>/<?php echo e($data->laptop_id); ?>>Delete</a></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
            <?php if(session()->has('members')): ?>
                <a href="insert_laptop">Insert</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>