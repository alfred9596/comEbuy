@extends('layout')

@section('pages')
<?php
    $datass=DB::select('select * from komponen where type = ?',[e($name)]);
?>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            @include('signin')
            <br>
            @include('cart')
    </div>
        </div>
    <div class="col-lg-10">
        <div class="container">
            <h1>Komponen Laptop</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Nama</th>
                    <th>Item Type</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    @foreach ($datass as $data)
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div>{{ $data->nama }}</div></td>
                        <td class="table-text"><div>{{ $data->type }}</div></td>
                        <td class="table-text"><div>{{ $data->brand }}</div></td>
                        <td class="table-text"><div>{{ $data->harga }}</div></td>
                        <td class="table-text"><div>{{ $data->deskripsi }}</div></td>
                        <td class="table-text"><div>{{ $data->inserter }}</div></td>
                        <!--<td><a href="">Add to cart</a></a> -->
                        
                    </tr>
                    @endforeach
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

@endsection