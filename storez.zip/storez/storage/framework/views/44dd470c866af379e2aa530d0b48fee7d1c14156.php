<?php $__env->startSection('pages'); ?>
<?php
    $searches=session('search');
    $searches1='%'.$searches.'%';
    $searches2=$searches.'%';
    $searches3='%'.$searches;
    echo "<script>alert(e(searches) );</script>";

    $datass=DB::select('select * from notebook where nama like ? or nama like ? or nama like ? or nama like ? or prosesor like ? or prosesor like ? or prosesor like ? or prosesor like ? or os like ? or os like ? or os like ? or os like ? or storage like ?  or storage like ?  or storage like ?  or storage like ? or ram like ?  or ram like ?  or ram like ?  or ram like ? or graphic like ?  or graphic like ?  or graphic like ?  or graphic like ? or koneksi like ?  or koneksi like ?  or koneksi like ?  or koneksi like ? or kamera like ?  or kamera like ?  or kamera like ?  or kamera like ? or display like ?  or display like ?  or display like ?  or display like ? or warna like ?  or warna like ?  or warna like ?  or warna like ? or harga like ?  or harga like ?  or harga like ?  or harga like ? or brand like ?  or brand like ?  or brand like ?  or brand like ? or inserter like ?  or inserter like ?  or inserter like ?  or inserter = ?',[$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3]);
    $datass2=DB::select('select * from aksesoris where nama like ? or nama like ? or nama like ? or nama like ? or type like ? or type like ? or type like ? or type like ? or brand like ? or brand like ? or brand like ? or brand like ? or  harga like ? or  harga like ? or  harga like ? or  harga like ? or deskripsi like ? or deskripsi like ? or deskripsi like ? or deskripsi like ? or inserter like ? or inserter like ? or inserter like ? or inserter like ?',[$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3]);
    $datass3=DB::select('select * from komponen where nama like ? or nama like ? or nama like ? or nama like ? or type like ? or type like ? or type like ? or type like ? or brand like ? or brand like ? or brand like ? or brand like ? or  harga like ? or  harga like ? or  harga like ? or  harga like ? or deskripsi like ? or deskripsi like ? or deskripsi like ? or deskripsi like ? or inserter like ? or inserter like ? or inserter like ? or inserter like ?',[$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3,$searches,$searches1,$searches2,$searches3]);
?>
<div class="row">
    <div class="col-lg-2">
        <div class="container">
            <?php echo $__env->make('signin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <br>
            <?php echo $__env->make('cart', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </div>
        </div>
    <div class="col-lg-10">
        <div class="container">
            <h1>Laptop</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Model</th>
                    <th>Processor</th>
                    <th>OS</th>
                    <th>Storage</th>
                    <th>RAM</th>
                    <th>Graphic</th>
                    <th>Connection</th>
                    <th>Camera</th>
                    <th>Display</th>
                    <th>Colour</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->nama); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->prosesor); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->os); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->storage); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->ram); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->graphic); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->koneksi); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->kamera); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->display); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->warna); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->brand); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->harga); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->inserter); ?></div></td>
                        <td><a href="">Add to cart</a></a> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
            <br><br>
            <h1>Komponen Laptop</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Nama</th>
                    <th>Item Type</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Description</th>
                    <th>inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->nama); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->type); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->brand); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->harga); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->deskripsi); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->inserter); ?></div></td>
                        <td><a href="">Add to cart</a></a>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
            <br><br>
            <h1>Aksesoris</h1>
            <div style="overflow-x:auto;">
            <table class="table table-striped"> 
                <thead>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Item Type</th>
                    <th>Brand</th>
                    <th>Inserter</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                    <th>&nbsp;</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $datass3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <!-- Task Name -->
                        <td class="table-text"><div><?php echo e($data->nama); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->deskripsi); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->harga); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->type); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->brand); ?></div></td>
                        <td class="table-text"><div><?php echo e($data->inserter); ?></div></td>
                        <td><a href="">Add to cart</a></a> 
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>