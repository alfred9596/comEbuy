<!--
<br><br>
	<table> 
		<thead>
			<th>Name</th>
			<th>&nbsp;</th>
			<th>Price</th>
			<th>&nbsp;</th>
		</thead>
		<tbody> <!--
		@foreach ($tasks as $task)
			<tr>
				<!-- Task Nam
				<td class="table-text"><div>{{ $task->name }}</div></td>
				<td class="table-text"><div>{{ $task->price }}</div></td>
				<td><!-- TODO: Delete Button 
						<form action="{{url('task')}}/{{$task->id}}" method="POST">
    					{{ csrf_field() }}
    					{{ method_field('DELETE') }}
			            <button class="btn btn-danger">delete item</button>
    				</form>
				</td>
			</tr>
		@endforeach-->

<!--		
		</tbody>
	</table>
